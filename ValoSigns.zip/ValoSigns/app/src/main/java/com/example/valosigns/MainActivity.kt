package com.example.valosigns

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var btnPickDate: Button
    private lateinit var btnCalculate: Button
    private lateinit var btnInfo: Button
    private lateinit var tvSelectedDate: TextView

    private var selectedMonth = -1 // 0-indexed (0 = Jan)
    private var selectedDay = -1

    // Data class representing an Agent configuration block
    data class Agent(
        val name: String,
        val month: Int, // 1-indexed for explicit setting
        val day: Int,
        val profile: String
    )

    // Explicit roster profile matrix mapped out
    private val agentRoster = arrayOf(
        Agent("Neon", 1, 15, "Fast-paced, energetic lightning duelist. Born mid-January under high kinetic pressure."),
        Agent("Fade", 2, 22, "Brings tracking nightmares and tactical shadows. Perfectly bound to late February frames."),
        Agent("Viper", 3, 20, "Corrosive area control scientist. Canonically observed celebrating on March 20th."),
        Agent("Killjoy", 4, 18, "Flawless genius tech architect. Her structural deployment mirrors late April precision."),
        Agent("Raze", 5, 12, "Explosive paint-shell engineer. High impact energy dominating mid-May timelines."),
        Agent("Skye", 6, 14, "Nurturing beast-master and pathfinder. Natural environment stabilizer tracking to June."),
        Agent("Reyna", 7, 23, "Fierce, self-reliant empress. High impact dominant soul matching late July."),
        Agent("Sova", 8, 19, "Impeccable tracker with relentless recon accuracy. Born mid-August."),
        Agent("Jett", 9, 21, "Agile execution specialist and wind runner. High velocity wind currents of late September."),
        Agent("Chamber", 10, 25, "Meticulous fashion and weaponry master. Sharp structural focus tracking late October."),
        Agent("Cypher", 11, 14, "Information broker keeping full records. High network surveillance signature of November."),
        Agent("Sage", 12, 18, "Solid barrier shield anchor and global healer. Patient, protective presence born in mid-December.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Bind Views
        btnPickDate = findViewById(R.id.btnPickDate)
        btnCalculate = findViewById(R.id.btnCalculate)
        btnInfo = findViewById(R.id.btnInfo)
        tvSelectedDate = findViewById(R.id.tvSelectedDate)

        // Date selection interaction interface
        btnPickDate.setOnClickListener {
            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(this,
                { _, year1, monthOfYear, dayOfMonth ->
                    selectedMonth = monthOfYear // Save 0-indexed values safely
                    selectedDay = dayOfMonth
                    tvSelectedDate.text = "$dayOfMonth/${monthOfYear + 1}/$year1"
                }, year, month, day
            )
            datePickerDialog.show()
        }

        // App Explanation/Instructions Popup (Fulfills informational modal rule) [cite: 6]
        btnInfo.setOnClickListener {
            showInfoModal(
                "VALOSIGNS BRIEF",
                "INSTRUCTIONS",
                "This application uses custom non-numeric calculation logic to compare your entry birthday matrix against canonical agent signatures to find your absolute operational proxy context. Select your real lifecycle birthday to run calculation."
            )
        }

        // Match Logic Processing Trigger
        btnCalculate.setOnClickListener {
            if (selectedMonth == -1 || selectedDay == -1) {
                Toast.makeText(this, "Please designate your target birthday timeline first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val closestAgent = findClosestAgent(selectedMonth + 1, selectedDay)
            showInfoModal("AGENT DETECTED", closestAgent.name, closestAgent.profile)
        }
    }

    // Distance calculation algorithm mapping calendar loops
    private fun findClosestAgent(userMonth: Int, userDay: Int): Agent {
        var bestMatch: Agent = agentRoster[0]
        var minDistance = 366

        val userDayOfYear = getDayOfYear(userMonth, userDay)

        for (agent in agentRoster) {
            val agentDayOfYear = getDayOfYear(agent.month, agent.day)
            var diff = abs(userDayOfYear - agentDayOfYear)

            // Accommodate standard circular calendar year-end wraps
            if (diff > 182) {
                diff = 365 - diff
            }

            if (diff < minDistance) {
                minDistance = diff
                bestMatch = agent
            }
        }
        return bestMatch
    }

    private fun getDayOfYear(month: Int, day: Int): Int {
        val daysInMonths = intArrayOf(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var daySum = day
        for (i in 1 until month) {
            daySum += daysInMonths[i]
        }
        return daySum
    }

    // Reusable Custom Pop-up Generator (Fulfills Modal View Criteria) [cite: 6, 18]
    private fun showInfoModal(titleHeader: String, agentName: String, bodyText: String) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_agent_info)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val title = dialog.findViewById<TextView>(R.id.modalTitle)
        val name = dialog.findViewById<TextView>(R.id.modalAgentName)
        val details = dialog.findViewById<TextView>(R.id.modalAgentDetails)
        val closeBtn = dialog.findViewById<Button>(R.id.modalCloseButton)

        title.text = titleHeader
        name.text = agentName
        details.text = bodyText

        closeBtn.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
}