package com.example.valostratbuilder

import android.os.Bundle
import android.widget.Button
import com.example.valostratbuilder.R
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class StrategyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_strategy)

        val tvMapTitle = findViewById<TextView>(R.id.tvMapTitle)
        val tvActiveRole = findViewById<TextView>(R.id.tvActiveRole)
        val tvStrategyContent = findViewById<TextView>(R.id.tvStrategyContent)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // Catch navigation extras from intent bundle
        val mapName = intent.getStringExtra("MAP_NAME") ?: "UNKNOWN"
        val userRole = intent.getStringExtra("USER_ROLE") ?: "General"

        tvMapTitle.text = mapName
        tvActiveRole.text = "Role Strategy Applied: $userRole"

        // Generate tailored USP context logic matching choices
        tvStrategyContent.text = generateStrategyText(mapName, userRole)

        btnBack.setOnClickListener {
            finish() // Safely close view stack layer to go back
        }
    }

    private fun generateStrategyText(map: String, role: String): String {
        return when (role) {
            "Duelist" -> "On Map $map, your primary focus is entry execution. Coordinate utility coverage to scale space past entry zones instantly."
            "Controller" -> "For $map execution layout protocols, lock vision blockers safely over sightlines. Prioritize keeping choke points covered."
            "Sentinel" -> "Defending structural ground on $map requires passive detection anchors. Lock down site entry loops and catch flank pathways cleanly."
            else -> "Study the universal tactical landscape on $map. Maintain map structural awareness and adapt site executions dynamically with team setups."
        }
    }
}