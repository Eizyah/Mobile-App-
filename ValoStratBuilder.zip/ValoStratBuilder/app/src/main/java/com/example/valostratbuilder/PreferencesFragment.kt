package com.example.valostratbuilder

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.Fragment

class PreferencesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_preferences, container, false)

        val rgRoles = view.findViewById<RadioGroup>(R.id.rgRolesTab)
        val btnSave = view.findViewById<Button>(R.id.btnSavePreferencesTab)

        val sharedPreferences = requireActivity().getSharedPreferences("ValoStratPrefs", Context.MODE_PRIVATE)
        val currentRole = sharedPreferences.getString("SavedRole", "")

        // Read and restore active data context states
        when(currentRole) {
            "Duelist" -> view.findViewById<RadioButton>(R.id.rbDuelistTab)?.isChecked = true
            "Controller" -> view.findViewById<RadioButton>(R.id.rbControllerTab)?.isChecked = true
            "Sentinel" -> view.findViewById<RadioButton>(R.id.rbSentinelTab)?.isChecked = true
        }

        btnSave.setOnClickListener {
            val selectedId = rgRoles.checkedRadioButtonId
            if (selectedId != -1) {
                val radioButton = view.findViewById<RadioButton>(selectedId)
                val selectedRoleText = radioButton.text.toString()

                sharedPreferences.edit().putString("SavedRole", selectedRoleText).apply()

                // Refresh main header bar state instantly
                (activity as? MainActivity)?.updateHeaderStatus()
                Toast.makeText(requireContext(), "Preferences Saved: $selectedRoleText", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
}