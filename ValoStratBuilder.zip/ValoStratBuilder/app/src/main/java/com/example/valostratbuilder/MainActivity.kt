package com.example.valostratbuilder

import android.content.Context
import android.os.Bundle
import android.widget.TextView
import com.example.valostratbuilder.R
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    private lateinit var tvHeaderStatus: TextView
    private val PREFS_NAME = "ValoStratPrefs"
    private val KEY_ROLE = "SavedRole"

    override fun onCreate(savedInstanceState: Bundle?) {
        // 1. FORCE THE APP INTO DARK MODE BEFORE THE WINDOW DRAWS
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvHeaderStatus = findViewById(R.id.tvHeaderPreferenceStatus)
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        val viewPager = findViewById<ViewPager2>(R.id.viewPager)

        updateHeaderStatus()

        // Bind Adapter to swap fragments when tabs are tapped
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 2
            override fun createFragment(position: Int): Fragment {
                return if (position == 0) DashboardFragment() else PreferencesFragment()
            }
        }

        // Setup the physical tab text labels
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = if (position == 0) "MAPS" else "PREFERENCES"
        }.attach()
    }

    fun updateHeaderStatus() {
        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedRole = sharedPreferences.getString(KEY_ROLE, "Unset")
        tvHeaderStatus.text = "Role: $savedRole"
    }
}