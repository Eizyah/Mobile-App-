package com.example.valostratbuilder

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class DashboardFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        val mapButtons = listOf(
            R.id.btnMapBind to "BIND", R.id.btnMapLotus to "LOTUS", R.id.btnMapSunset to "SUNSET",
            R.id.btnMapPearl to "PEARL", R.id.btnMapAscent to "ASCENT", R.id.btnMapFracture to "FRACTURE",
            R.id.btnMapBreeze to "BREEZE", R.id.btnMapSplit to "SPLIT", R.id.btnMapHaven to "HAVEN"
        )

        for ((id, name) in mapButtons) {
            view.findViewById<Button>(id)?.setOnClickListener {
                launchStrategyView(name)
            }
        }

        return view
    }

    private fun launchStrategyView(mapName: String) {
        val sharedPreferences = requireActivity().getSharedPreferences("ValoStratPrefs", Context.MODE_PRIVATE)
        val savedRole = sharedPreferences.getString("SavedRole", "General") ?: "General"

        val intent = Intent(requireContext(), StrategyActivity::class.java).apply {
            putExtra("MAP_NAME", mapName)
            putExtra("USER_ROLE", savedRole)
        }
        startActivity(intent)
    }
}